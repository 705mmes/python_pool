#!/usr/bin/env python3
# -*- coding: utf-8 -*-?

def count_in_list(lst, find):
    return lst.count(find)
